/**
 * Function to update the Free Shipping Progress Bar dynamically.
 * Threshold: 49.99 EUR.
 * Text updated to German and "vegan" removed per client request.
 */
function updateFreeShippingProgress(cart) {
  const threshold = 4999; // 49.99 EUR in cents
  const total = cart.total_price;
  const barFill = document.getElementById('shipping-progress');
  const messageContainer = document.getElementById('shipping-message');

  if (!barFill || !messageContainer) return;

  if (total < threshold) {
    const remaining = (threshold - total) / 100;
    const percentage = (total / threshold) * 100;
    
    // Formatting: €35,00 style for German market
    const formattedAmount = '€' + remaining.toFixed(2).replace('.', ',');
    
    // Updated German message without "vegan"
    messageContainer.innerHTML = `Nur noch <strong>${formattedAmount}</strong> bis zum kostenlosen Versand für deine Essentials!`;
    barFill.style.width = percentage + '%';
    messageContainer.classList.remove('success');
  } else {
    // Success message in German
    messageContainer.innerHTML = `Herzlichen Glückwunsch! Du hast kostenlosen Versand freigeschaltet.`;
    barFill.style.width = '100%';
    messageContainer.classList.add('success');
  }
}

class MCartDrawer extends HTMLElement {
  constructor() {
    super(),
    this.cartDrawerInner = this.querySelector(".m-cart-drawer__inner"),
    this.cartDrawerCloseIcon = this.querySelector(".m-cart-drawer__close"),
    this.cartOverlay = this.querySelector(".m-cart__overlay"),
    this.rootUrl = window.Shopify.routes.root,
    this.setHeaderCartIconAccessibility(),
    this.cartDrawerCloseIcon.addEventListener("click", this.close.bind(this)),
    this.addEventListener("click", (t => {
      t.target.closest(".m-cart-drawer__inner") !== this.cartDrawerInner && this.close()
    }))
  }
  setHeaderCartIconAccessibility() {
    document.querySelectorAll(".m-cart-icon-bubble").forEach((t => {
      t.setAttribute("role", "button"),
      t.setAttribute("aria-haspopup", "dialog"),
      t.addEventListener("click", (e => {
        MinimogSettings.enable_cart_drawer && (e.preventDefault(), this.open(t))
      }))
    }))
  }
  open(t) {
    t && this.setActiveElement(t),
    this.classList.add("m-cart-drawer--active"),
    requestAnimationFrame((() => {
      this.style.setProperty("--m-bg-opacity", "0.5"),
      this.cartDrawerInner.style.setProperty("--translate-x", "0")
    })),
    window.MinimogEvents.emit(MinimogTheme.pubSubEvents.openCartDrawer)
  }
  close() {
    this.style.setProperty("--m-bg-opacity", "0"),
    this.cartDrawerInner.style.setProperty("--translate-x", "100%"),
    setTimeout((() => {
      this.classList.remove("m-cart-drawer--active")
    }), 300)
  }
  renderContents(t) {
    this.classList.contains("m-cart--empty") && this.classList.remove("m-cart--empty"),
    this.productId = t.id,
    this.getSectionsToRender().forEach((e => {
      (e.selector ? document.querySelector(e.selector) : document.getElementById(e.id)).innerHTML = this.getSectionInnerHTML(t.sections[e.id], e.selector)
    })),
    setTimeout((() => {
      this.open(),
      window.FoxKitV2 && window.FoxKitV2.Modules.InCart && window.FoxKitV2.Modules.InCart.getCart()
    }))
  }
  updateCartCount(t) {
    document.querySelectorAll(".m-cart-count-bubble").forEach((e => {
      t > 0 ? (e.textContent = t, e.classList.remove("hidden")) : e.classList.add("hidden")
    }))
  }
  getCart() {
    return fetchJSON(this.rootUrl + "cart.json")
  }
  onCartDrawerUpdate(t = !0) {
    fetch(`${MinimogSettings.routes.cart}?section_id=cart-drawer`).then((t => t.text())).then((e => {
      this.getSectionsToRender().forEach((r => {
        if ("cart-items" === r.block) {
          (r.selector ? document.querySelector(r.selector) : document.getElementById(r.id)).innerHTML = this.getSectionInnerHTML(e, r.selector),
          window.FoxKitV2 && window.FoxKitV2.Modules.InCart && window.FoxKitV2.Modules.InCart.getCart()
        } else if (t) {
          (r.selector ? document.querySelector(r.selector) : document.getElementById(r.id)).innerHTML = this.getSectionInnerHTML(e, r.selector)
        }
      }))
    })).catch((t => {}));
    
    this.getCart().then((t => {
      this.classList.toggle("m-cart--empty", 0 === t.item_count),
      this.updateCartCount(t.item_count);
      // Update the Free Shipping Bar dynamically after cart changes
      updateFreeShippingProgress(t);
    }))
  }
  getSectionInnerHTML(t, e = ".shopify-section") {
    return (new DOMParser).parseFromString(t, "text/html").querySelector(e).innerHTML
  }
  getSectionsToRender() {
    return [{
      id: "cart-drawer",
      selector: "[data-minimog-cart-items]",
      block: "cart-items"
    }, {
      id: "cart-drawer",
      selector: "[data-minimog-cart-discounts]",
      block: "cart-footer"
    }, {
      id: "cart-drawer",
      selector: "[data-cart-subtotal]",
      block: "cart-footer"
    }, {
      id: "cart-drawer",
      selector: "[data-minimog-gift-wrapping]",
      block: "cart-footer"
    }]
  }
  getSectionDOM(t, e = ".shopify-section") {
    return (new DOMParser).parseFromString(t, "text/html").querySelector(e)
  }
  setActiveElement(t) {
    this.activeElement = t
  }
}
customElements.define("m-cart-drawer", MCartDrawer);

class MCartDrawerItems extends MCartTemplate {
  getSectionsToRender() {
    return [{
      id: "MinimogCartDrawer",
      section: "cart-drawer",
      selector: "[data-minimog-cart-items]"
    }, {
      id: "MinimogCartDrawer",
      section: "cart-drawer",
      selector: "[data-minimog-cart-discounts]"
    }, {
      id: "MinimogCartDrawer",
      section: "cart-drawer",
      selector: "[data-cart-subtotal]"
    }, {
      id: "MinimogCartDrawer",
      section: "cart-drawer",
      selector: "[data-minimog-gift-wrapping]"
    }]
  }
}
customElements.define("m-cart-drawer-items", MCartDrawerItems);

/**
 * Advanced MutationObserver to detect Add to Cart events.
 * Listens for changes in the cart items container and updates the bar.
 */
const cartObserver = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
    if (mutation.type === 'childList' || mutation.type === 'subtree') {
      fetch(`${window.Shopify.routes.root}cart.json`)
        .then(res => res.json())
        .then(cart => updateFreeShippingProgress(cart))
        .catch(err => console.error("Progress bar update failed:", err));
    }
  });
});

// Target the Minimog cart items container for observation
const cartTarget = document.querySelector('[data-minimog-cart-items]');
if (cartTarget) {
  cartObserver.observe(cartTarget, { childList: true, subtree: true });
}

// Global event listener for standard cart updates
document.addEventListener('cart:updated', function(event) {
  if (event.detail && event.detail.cart) {
    updateFreeShippingProgress(event.detail.cart);
  }
});